#8. Write a program to enter two integers and then perform all arithmetic operations on them. 

a=int(input("enter value of a"))
b=int(input("enter value of b"))
print("a+b =",a+b)
print("a-b =",a-b)
print("a*b =",a*b)
