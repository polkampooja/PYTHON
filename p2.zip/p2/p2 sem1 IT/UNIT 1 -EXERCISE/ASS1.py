#1. Write a program that asks two people for their names; stores the names in variables called name1 and 
#name2; says hello to both of them


name1=str(input("what is your name1" ))
name2=str(input("what is  your name2"))
print  ( "hello " +name1 + " " + name2)
