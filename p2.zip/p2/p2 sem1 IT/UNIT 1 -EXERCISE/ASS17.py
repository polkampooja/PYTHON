#17. Write a program to calculate average of two numbers. Print their deviation."""
a=int(input("value of a="))
b=int(input("value of b="))
avg=(a+b)/2
print( avg)
d1=a-avg
d2=b-avg
print("deviation of a=", d1)
print("deviation of b=" ,d2)
