"""13. Write a program that prompts users to enter two integers x and y. The program then calculates and
display x y ."""
x=int(input("enter the x value"))
y=int(input("enter the y value"))
print("exponent is=%i" %x**y)
