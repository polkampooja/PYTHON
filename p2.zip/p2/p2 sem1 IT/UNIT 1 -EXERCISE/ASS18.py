#18. Write a program to covert a floating point number into the corresponding integer. 

a=float(input("enter the float"))
print(int(a))
