#3. Write a Python program which accepts the user's first and last name and print them in reverse order 
#with a space between them. 
name1=(input("enter firstname"))
name2=(input("enter lastname"))
print(name2 + " " + name1)

       
