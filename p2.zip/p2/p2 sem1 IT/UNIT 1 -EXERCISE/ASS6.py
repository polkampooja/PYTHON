#6. Write a python program to sum of the first n positive integers. 

n =int(input("enter n value"))
sum=(n*(n+1)/2)
print("sum n positive numbers" ,sum)
