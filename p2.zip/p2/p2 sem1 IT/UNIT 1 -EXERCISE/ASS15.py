#15.  Write a program to calculate salary of an employee given his basic pay(to be entered by the user), HRA 
#=10 percent of basic pay, TA=5 percent of basic pay. Define HRA and TA as constants and use them to 
#calculate the salary of the employee


import constant
basic =int(input("enter basic pay"))
H=constant.HRA*basic
T=constant.TA*basic
total=H+T+basic
print(total)

