#16. Write a program to print the digit at one’s place of Number. 

a=int(input("enter the value of a"))
once=a%10
print( "once digit of a number" ,once)

      
