#14. Write a program that calculates numbers of seconds in a day.
h=int(input("enter value of h"))
m=int(input("enter value of m"))
s=int(input("enter value of s"))
a=h*m*s
print ("seconds in a day= " ,a)
