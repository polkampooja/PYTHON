#20. Write a program to calculate area of triangle using Heron’s formula. ( Hint: Heron’s formula is :  
#area = sqrt(s*(s-a)*(s-b)*(s-c)) 
 

import math
a=int(input("enter the value of a"))
b=int(input("enter the value of b"))
c=int(input("enter the value of c"))
s=(a+b+c)/2
print("sides of the trianle is=",s)
d=math.sqrt(s*(s-a)*(s-b)*(s-c))
print("area of triangle is=",d)
