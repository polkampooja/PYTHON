#19. Write a program to convert a integer into the corresponding floating point number. 
a=float(input("enter the value a"))
print(int(a))
