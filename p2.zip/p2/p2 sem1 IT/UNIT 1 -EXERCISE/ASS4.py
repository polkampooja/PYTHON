#4. Write a Python program that will accept the base and height of a triangle and compute the area. 

base=int(input("enter the base"))
height=int(input("enter the height"))
area=base*height*1/2
print("area" ,area)
