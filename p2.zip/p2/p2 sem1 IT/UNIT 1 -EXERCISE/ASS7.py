#7. Write a Python program to swap two variables

a=int(input("enter a"))
b=int(input("enter b"))
temp=a
a=b
b=temp
print("b=",a)
print("a=",b)
