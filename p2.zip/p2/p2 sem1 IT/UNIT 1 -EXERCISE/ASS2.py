r=1.1
pi=3.14
area_of_circle=(pi*r**2)
print( "area" ,area_of_circle )

#2.  Write a Python program which accepts the radius of a circle from the user and compute the area.  
#Sample Output :  
#r = 1.1 Area = 3.8013271108436504

import math
r=float(input("enter r"))
area=math.pi*r*r
print(area)

     
