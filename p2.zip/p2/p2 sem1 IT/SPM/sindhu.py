
#s
for row in range (5):
    for col in range (5):
        if (row==0 or row==2  or row==4 or(col==0 and row==1) or(col==4 and row==3)):
           print("@",end=' ')
        else:
            print( ' ',end=' ')
    print()

#i
for row in range (5):
    for col in range (5):
        if(col==2  or (row==0 or (row==4 ))):
           print("*",end=' ')
        else:
            print( ' ',end=' ')
    print()


#N
for row in range (5):
    for col in range (5):
        if (col==0 or (col==4 )):
            print("N",end=' ')
        elif((row==1 and col==1) or (row==2 and col==2) or (row==3 and col==3)):
            print('N',end=" ")
        else:
            print(' ',end=" ")
    print()

#d
for row in range (5):
    for col in range (5):
        if((row==0 and col==4) or (row==4 and col==4)):
            print(' ',end=" ")
        elif((row==0 or  row==4 or col==0 or col==4)):
            print("#",end=' ')

        else:
            print( ' ',end=' ')
    print()
#h
for row in range (5):
    for col in range (5):
        if (col==0 or col==4 or row==2 ):
            print("*",end=' ')
        else:
            print(' ',end=" ")
    print()

#u
for row in range (5):
    for col in range (5):
        if (col==0 or col==4 or row==4 ):
            print("#",end=' ')
        else:
            print(' ',end=" ")
    print()
