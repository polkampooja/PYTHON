n=1
while(n<=10):
	print("*")
	n=n+1







