n=int(input("enter the value of x"))
i=0
while(i<=n):
    print(n)
    n=n-1
