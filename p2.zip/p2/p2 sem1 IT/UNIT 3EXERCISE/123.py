m=int(input("enter initial range"))
n=int(input("enter end range"))
while(m<=n):
	print(m,"pooja",end=",")
	m=m+1
