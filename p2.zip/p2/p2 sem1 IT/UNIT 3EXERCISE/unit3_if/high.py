n=int(input("enter no="))
if(n>0):
	if(n>100):
		print("high")
	else:
		print("low")
else:
	print("negative number")

