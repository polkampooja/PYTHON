sub1=int(input("enter sub1 marks="))
sub2=int(input("enter sub2 marks="))
sub3=int(input("enter sub3 marks="))
sub4=int(input("enter sub3 marks="))
total=sub1+sub2+sub3+sub4
aggr=total/4
if((sub1>=35)and(sub2>=35)and(sub3>=35)and(sub4>=35)):
	if(aggr>=75):
		print("distinction")
	elif(aggr>=60 and aggr<75):
		print("first division")
	elif(aggr>=50 and aggr<60):
		print("second division")
	elif(aggr>=40 and aggr>50):
		print("third division")
	else:
		print("fail")
else:
	print("fail")




