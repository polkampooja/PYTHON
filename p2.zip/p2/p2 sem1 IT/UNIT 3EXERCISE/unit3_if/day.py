a=input("enter the number between 1-7")
if(a==1):
	print("sunday")
elif(a==2):
	print("monday")
elif(a==3):
	print("tuesday")
elif(a==4):
	print("wednesday")
elif(a==5):
	print("thursday")
elif(a==6):
	print("friday")
elif(a==7):
	print("saturday")
else:
	print("please enter the valid day")
