ch=input("enter any input")
if((ch>='0')and (ch<='9')):
	print("digit")
elif((ch>='a')and (ch<='z')):
	print("lower case")
elif((ch>='A')and (ch<='z')):
	print("upper case")
else:
	print("not digit nor character")
