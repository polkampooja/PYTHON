a=input("enter any character")
if(a=='O'):
	print("OUTSTANDING")
elif(a=='A'):
	print("VERY GOOD")
elif(a=='B'):
	print("GOOD")
elif(a=='C'):
	print("AVERAGE")
elif(a=='F'):
	print("BELOW AVERAGE")
else:
	print("given one is out of the character")
