a=int(input("enter value="))
b=int(input("enter value="))
c=int(input("enter value="))
if((a>b)and(a>c)):
	print(a,"is greater")
elif(b>c):
	print(b,"is greater")
elif(c>a):
	print(c,"is greater")
	

else:
	print("all are equal")
	
        
