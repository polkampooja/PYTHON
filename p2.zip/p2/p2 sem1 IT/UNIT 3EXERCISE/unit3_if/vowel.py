ch=raw_input("enter any character")
t=('a','e','i','o','u','A','E','I','O','U')
if(ch in t):
	print(ch ,"is vowel")
else:
	print(ch ,"is not vowel")
