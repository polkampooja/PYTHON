a=int(input("enter the number="))
b=int(input("enter the number="))
if(a%b==0):
	print("a is multiple of b")
else:
	print("not multiple")
