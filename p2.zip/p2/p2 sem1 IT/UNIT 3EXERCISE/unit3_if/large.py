a=int(input("enter a value="))
b=int(input("enter b value="))
if(a>b):
	print(a,"is greater")
else:
	print(b,"is greater")
