import math
a=int(input("enter coefficient of x2="))
b=int(input("enter x coefficient="))
c=int(input("enter constant="))
D=(b*b)-(4*a*c)
if(D==0):
	print (" roots are real and equal")
	print("roots are=",(-b)/(2*a))
elif(D>0):
	print ("roots are real and distinct")
	r1=(-b+math.sqrt(D))/(2*a)
	r2=(-b-math.sqrt(D))/(2*a)
	print("roots are=", r1,r2)
else:
	print ("roots are imaginary")
