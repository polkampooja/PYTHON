income=int(input("enter the income="))
if(income<=150000):
	print("no tax")
elif(income>=150001 and income<300000):
	print("tax=", (10/100)*income)
elif(income>=300001 and income<500000):
	print("tax=",(20/100)*income)
else:
	print("tax=",(30/100)*income)
