salary=int(input("enter salary of employee="))
gender=str(input("enter the gender of employee="))
if(gender=="female"):
        if(salary<=10000):
                bonus=(12/100)*salary
 	else:
                bonus=(10/100)*salary
else:
        if(salary<=10000):
                bonus=(7/100)*salary
	else:
                bonus=(5/100)*salary
print("salary of the employee=",salary+bonus)
