#13. Write a program to read a number from the user
#and find whether it is a palindrome number or not. 
n=int(input("enter the number"))
t=n
s=0
while(n>0):
    r=n%10
    s=(s*10)+r
    n=n//10
if(t==s):
    print(t,"is a palindrome")
else:
    print(t,"is a not palindrome")
