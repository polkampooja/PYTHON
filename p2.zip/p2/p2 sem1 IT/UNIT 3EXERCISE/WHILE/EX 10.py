#10. Write a program to enter a number and then calculate the sum of the digits. 
n=int(input("enter the number"))
s=0
c=0
while(n>0):
    rem=n%10
    s=s+rem
    n=n//10
    c=c+1# to count no. of iterations
print(s)
print(c)
