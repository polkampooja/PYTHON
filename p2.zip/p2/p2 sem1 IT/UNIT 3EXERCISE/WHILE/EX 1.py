#1. Write a program to calculate the sum and average of first 10 numbers.
n=int(input("enter the value"))
sum=0

while(n<=10):
	sum=sum+n
	n=n+1
print(sum)
avg=sum/n
print(avg)


                        
