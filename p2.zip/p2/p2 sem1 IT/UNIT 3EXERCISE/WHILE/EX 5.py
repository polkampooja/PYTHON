#5. Write a program to read the numbers until -1 is encountered.
#Find the average of positive number and negative numbers entered by the user. 
pcs=ncs=0
pc=nc=0
while(1):
    n=int(input("enter the value"))
    if(n==-1):
       print("break")
    elif(n>0):
        pc=pc+1
        pcs=pcs+n
        print("pva",pcs/pc)
    elif(n<0):
        nc=nc+1
        ncs=ncs+n
        print("nca",ncs/nc)
    else:
        zc=zc+1


