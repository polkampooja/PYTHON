#14. Write program using a while loop that asks the user
#for a number and prints a countdown from that number to zero. 
i=int(input("enter the value of i"))
while(i>=0):
    print(i)
    i=i-1
