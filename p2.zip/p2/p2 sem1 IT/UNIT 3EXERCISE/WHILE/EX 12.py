#12. Write a program to print the reverse of a number
n=int(input("enter the number"))
while(n!=0):
    Remainder=n%10
    print(Remainder,end=" ")
    n=int(n/10)
