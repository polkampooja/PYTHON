#7. Write a program to enter a decimal number.
#Calculate and display the binary equivalent of this number
decimal_number=int(input("enter the value of dn"))
binary_number=0
i=0
while(decimal_number>0):
    r=(decimal_number%2)
    binary_number=(binary_number+(r*(10**i)))
    decimal_number=(decimal_number//2)
    i=i+1
print("binary number is =",binary_number)
