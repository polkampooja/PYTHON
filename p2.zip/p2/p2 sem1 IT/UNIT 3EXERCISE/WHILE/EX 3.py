#3. Write a program to calculate the sum of numbers from m to n. 
m=int(input("enter the two number : "))
n=int(input("enter the two number :"))
s=0
while(m<=n):
    s=s+m
    m=m+1
print("sum = ",s)
    
    
