#4. Write a program to read the numbers until -1 is encountered.
#Also count the negative, positive and zeros entered by user. 
pc=nc=zc=0
while( 1):
    num=int(input("enter the value"))
    if(num==-1):
        print("break")
    elif(num>0):
        pc=pc+1
    elif(num<0):
        nc=nc+1
    else:
        zc=zc+1
print(pc,nc,zc )
