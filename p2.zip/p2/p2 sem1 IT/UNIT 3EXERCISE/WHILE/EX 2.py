#2. Write a program to print 20 horizontal asterisks(*). 
n=1
while(n<=20):
	print('*',end=' ')
	n=n+1
