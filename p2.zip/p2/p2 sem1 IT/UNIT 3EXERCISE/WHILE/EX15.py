#15. Write a program that prompts users to enter numbers.
#Once the user enters -1, it displays the count,
#sum and average of even numbers and that of odd numbers. 
ec=esum=eavg=oc=osum=oavg=0
n=1
while(n!=-1):
	n=int(input("enter n value:-1 to exit"))
	if(n%2==0):
		ec=ec+1
		esum=esum+n
	else:
		oc=oc+1
		osum=osum+n
print("ec=",ec,"esum=",esum,"eavg=",esum/ec)
print("oc=",oc,"osum=",osum,"oavg=",osum/oc)
