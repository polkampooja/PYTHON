#8. Write a program to enter a binary number and convert it into decimal number. 
n=int(input("enter bin number"))
i=0
s=0
while(n>0):
    r=n%10
    s=s+(r*(2**i))
    n=n//10
    i=i+1
print("decimal value is ", s)
