#6. Write a program to find whether the given number is an
#Armstrong Number or not 
n=int(input("enter the number :"))
s=0
num=n
while(n>0):
    remainder=n%10
    #print(remainder,end=" ")
    s=s+(remainder**3)
    n=(n//10)
if(s==num):
    print("the number is armstrong")
else:
    print("the number is not armstrong")
    
    
