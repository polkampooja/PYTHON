a=input("enter the string:")
n=len(a)
for i in range(0,n):
    print(" " *i,end=" ")
    for j in range(n-i):
        print(a[j],end=" ")
    print()
