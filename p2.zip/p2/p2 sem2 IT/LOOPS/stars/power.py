
def exp(x,y):
    if (y==0):
        return 1
    else:
        return(x*exp(x,y-1))
x=int(input("enter the value of x"))
y=int(input("enter the value of y"))
print(exp(x,y))
