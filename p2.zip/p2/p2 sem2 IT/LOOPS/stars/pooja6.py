
#1 
#2 3 
#4 5 6 
#7 8 9 10 
#11 12 13 14 15
n=int(input("enter the value of n"))
k=1
for i in range (1,n):
    for j in range (1,i+1):
        print(k,end=" ")
        k=k+1
    print()
        
    
