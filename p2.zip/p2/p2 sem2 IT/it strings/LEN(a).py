a=input("enter the value of a")
b=0
for i in a:
    b=b+1
print(b)









