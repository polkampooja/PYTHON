a=input("enter the string")
b=(a.split())
print(b[: : -1])

#c=(b[: : -1])
#print(" " .join(c))


#b.reverse()
#
print(' '.join(b))



