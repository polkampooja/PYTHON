a=[]
n=int(input("enter the size  of list"))
for i in range(0,n):
    print("enter{} elements".format(i))
    item=int(input("enter elements"))
    a.append(item)
print("list is",a)
def insortion_sort (a):
    for i in range(1,n):
        key=a[i]
        j=i-1
        while j >= 0 and key < a[j]:
            a[j+1]=a[j]
            j=j-1
        a[j+1]=key
    return a
result=insortion_sort(a)

print("after insertion sort:",result)
