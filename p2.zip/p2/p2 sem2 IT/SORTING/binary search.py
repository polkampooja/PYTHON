a=[]
n=int(input("enter size length"))
for i in range(1,n+1):
    print("enter {} element".format (i))
    item=int(input("enter"))
    a.append(item)
print(a)
key=int(input("Enter search element"))

def binarysearch(a,key):
    start=0
    end=n-1
    
    while(start<=end):
        mid=(start+end)//2
        if(a[mid]==key):
           return mid
        elif(key>a[mid]):
           start=mid+1
        else:
           end=mid-1
    return-1
result = binarysearch (sorted(a),key)
if(result == -1):
    print(key,"is not found")
else:
    print(key,"is  in list at index of",result)



    
    
