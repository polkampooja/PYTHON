a=[]
n=int(input("enter the size"))
for i in range(0,n):
    print("enter {} element".format(i))
    item=int(input("enter the elements"))
    a.append(item)
print("list is :",a)


def bubble_sort(a):
    for i in range(0,n):
        for j in range(n-1-i):
            if a[j] > a[j+1]:
                temp=a[j]
                a[j]=a[j+1]
                a[j+1]=temp
    return a
result=bubble_sort(a)
print("after bubble sort:",result)
                
                
                
            
    
