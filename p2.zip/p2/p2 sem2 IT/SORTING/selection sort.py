size=int(input("enter the size of list"))
a=[]
for i in range(0,size):
    print("enter {} elements".format(i))
    item=int(input("enter the elements"))
    a.append(item)
print("list is:",a)
    

def selection_sort(a):
    for i in range (len(a)):
        minimum=i
        for j in range(i+1,len(a)):
            if a[j] < a[minimum]:
                minimum=j
        temp=a[i]
        a[i]=a[minimum]
        a[minimum]=temp
    return a
result=selection_sort(a)
print("after doing  selection sort:",result)

