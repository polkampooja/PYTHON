f=open("my file.txt","r")
g=f.read(3)
print(g)
f.close
