import os
if os.path.exists("hello"):
    print("directory exists")
else:
    print("directory does not exists")
