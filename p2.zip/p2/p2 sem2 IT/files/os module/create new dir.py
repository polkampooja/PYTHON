import os
if os.path.exists("happy"):
    print("directory exists")
else:
    os.mkdir("happy")
    print("directory created")
