import os
if os.path.exists("hi.txt"):
    print("file exists")
else:
    print("file is does not exists")
