import os
if os.path.exists("happy"):
    os.rmdir("happy")
    print("directory removed")
else:
    print("directory does not exist")
