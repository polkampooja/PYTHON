f=open("my file.txt","r")
l=f.readlines(6)
for i in l:
    print(i)
f.close
