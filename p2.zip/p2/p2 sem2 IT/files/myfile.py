f=open("my file.txt","w")
f.write("abcd \n efgh\n ijkl \n mnop")
f.close()
print("file success")
