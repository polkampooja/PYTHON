try:
    a=int(input("enter a number"))
    b=int(input("enter a number"))
    print("sum is :",a+b)
    print("division is :",a/b)
except ValueError:
    print("invalid input")
except ZeroDivisionError:
    print("you can't divide with zero")
else:
    print("try executed")
finally:
    print("thank you")

    
