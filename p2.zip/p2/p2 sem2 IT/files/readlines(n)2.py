f=open("my file.txt","r")
l=f.readlines(4)
for i in l:
    print(i)
f.close
