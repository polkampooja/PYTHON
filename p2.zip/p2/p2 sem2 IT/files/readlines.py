f=open("my file.txt","r")
l=f.readlines()
for i in l:
    print(i)
f.close
