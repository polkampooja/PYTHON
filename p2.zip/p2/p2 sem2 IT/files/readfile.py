f=open("my file.txt","r")
g=f.read()
print(g)
f.close()
