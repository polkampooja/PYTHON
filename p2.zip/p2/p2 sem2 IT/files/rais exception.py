num=int(input("enter a positive number"))
if num<0:
    raise Exception ("please input only positive value")
    #print("pooja")
print("num=",num)
