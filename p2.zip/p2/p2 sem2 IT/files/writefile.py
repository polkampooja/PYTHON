f=open("poojafile.txt","w")
f.write("hello")
f.close()
print("file saved")
