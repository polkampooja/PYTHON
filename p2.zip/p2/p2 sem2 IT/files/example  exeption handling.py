try:
    print("Hello")
except:
    print("Something went wrong")
else:
    print("Nothing went wrong") 
