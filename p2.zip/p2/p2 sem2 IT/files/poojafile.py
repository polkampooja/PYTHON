poojafile=open("poojafile.txt","w")
poojafile.write("pooja,oodmornin")
poojafile.close()
print("succesfull")


poojafile=open("poojafile.txt","a")
poojafile.write("pooja hellooooo")
poojafile.close()
print("succesfull")




poojafile=open("poojafile.txt","r")
a=poojafile.read()
poojafile.close()
print(a)
print("succesfull")

poojafile=open("poojafile.txt","r")
a=poojafile.read(1)
poojafile.close()
print(a)
print("succesfull")


poojafile=open("poojafile.txt","r")
a=poojafile.readline()
poojafile.close()
print(a)
print("succesfull")


poojafile=open("poojafile.txt","r")
a=poojafile.readlines()
poojafile.close()
print(a)
print("succesfull")


poojafile=open("poojafile.txt","r")
a=poojafile.readlines()
for i in a:
    print(i)
poojafile.close()




import os
if os.path.exists("poojafile.txt"):
    print("fileexists")
else:
    print("file not exits")





import os
if os.path.exists("os module"):
    print("directory exists")
else:
    print("directory not exits")



import os
if os.path.exists("poojafile.txt"):
    os.remove("poojafile.txt")
    print("file removed")
else:
    print("file not exits")


import os
if os.path.exists("poojafile.txt"):
    print("fileexists")
else:
    print("file not exits")
















