f=open("hi.txt","w")
f.write("happy")
f.close
print("done")
