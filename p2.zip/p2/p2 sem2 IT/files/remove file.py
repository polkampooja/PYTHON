import os
if os.path.exists("hi.txt"):
    os.remove("hi.txt")
    print("file removed")
else:
    print("directory does not exists")
