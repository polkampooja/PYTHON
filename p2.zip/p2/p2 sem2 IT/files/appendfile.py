f=open("newfile.txt","a")
f.write("hello polkam")
f.close()
print("file saved")
