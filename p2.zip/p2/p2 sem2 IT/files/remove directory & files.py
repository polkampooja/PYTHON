import os
if os.path.exists("happy"):
    
    li=os.listdir("./happy")
    print(li)
    for i in li:
        os.remove("./happy/"+i)
    os.rmdir("happy")
    print("directory removed")
else:
    print("directory doesnot exists")
