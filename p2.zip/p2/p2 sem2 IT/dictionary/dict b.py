a1={}
size=int(input("enter the size"))
for i in range(0,size):
    key=input("enter the key ")
    val=input("enter the value")
    a1[key]=val
print(a1)
a1.update(a1)
print(a1)
