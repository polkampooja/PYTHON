s="pooja"
dict=()
for i in s:
    dict(i)=s.count(i)
print(dict)
