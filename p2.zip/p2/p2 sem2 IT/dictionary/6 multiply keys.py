my_dict = {'data1':100,'data2':54,'data3':2}
k=1
for i in my_dict:
    k=k*my_dict[i]
print(k)
