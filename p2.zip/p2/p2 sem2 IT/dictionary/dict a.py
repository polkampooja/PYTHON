a={1:2,2:4,3:9,4:16}
print(a[1])
print(a[2])
print(a.get(2))
print(a.keys())
print(a.values())
print(a.items())

a[5]=25
print(a)
