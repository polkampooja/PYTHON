#Sample: d = {'Red': 1, 'Green': 2, 'Blue': 3}
#Output:  Red corresponds to  1                                                                                          
#Blue corresponds to  3                                                                                         
#Green corresponds to  2


d = {'Red': 1, 'Green': 2, 'Blue': 3}
for i in d:
    print(i ,"corresponds to", d[i])



 
