a=[]
b=int(input("enter"))
for i in range (0,b):
  n=input("enter")
  a=a+[n]
print(a)
