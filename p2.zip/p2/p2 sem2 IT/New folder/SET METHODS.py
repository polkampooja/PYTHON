#METHODS:

#1): setname.add(element)
a={1,2,3,4}
a.add(5)
print(a)

#2):set1.update(set2)
b={6,7}
a.update(b)
print(a)

#3):setname.remove(element)
a.remove(5)
print(a)

#4):setame.discard(element)
a.discard(2)
a.discard(1)
a.discard(3)
a.discard(4)
#a.remove(8)#error message
a.discard(8)#

#5):setname.pop()
a.pop
print(a)

#6):SETname.clear()
a.clear()
print(a)

#7):setnmae.copy()
x={1,2,3}
y=x.copy() #or y=x
print(y)

#8):set.subset(set2)
a={1,2,3,4,10}
b={1,2,3,4,5}
print(a.issubset(b))

#9):set1.issuperset(set2)
print(a.issuperset(b)) #0r
print(a>b)

 #10):set1.union(set2) or set1/set2
#print(a/b)

#11):set1.intersection
a={1,2,3,10}
b={1,2,3,4,5}
print(a & b)


#12):set1.intersection_update(set2)
a.intersection_update(b) #it stores values in a
print(a)

#13):set1.difference(set2) or set1-set2
a={1,2,3,6}
b={1,2,3,4,5}
print(a-b)#6

#14):set1.difference_update(set2)
a.difference_update(b)
print(a)

#15);set1.symmetric_differance(set2)
x={1,2,3,8,9}
y={1,2,3,10}
print(x.symmetric_difference(y))#{8,9,10} #except common elements it prints remaining elements
      




