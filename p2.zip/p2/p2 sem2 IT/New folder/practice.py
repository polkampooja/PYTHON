a=set()
print(type(a))


s=set("hello, pooja")
for i in s:
    print(i,end=" ")
