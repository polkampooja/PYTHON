t=tuple(input("any word"))
print(t)
