t=("string",2,100,6+0j,(12,43,99))
print(t)
