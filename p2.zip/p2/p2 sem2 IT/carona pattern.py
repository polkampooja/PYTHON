a=input("enter the string:")
len=len(a)
for i in range(0,len):
    for j in range(i+1):
       print(a[j],end=" ")
    print()





