t = (1,2,3,4,2,3,4,4,5)
print(t)
max = 0
count=0
for i in t:
    if(t.count(i) >  max):
        max = i
        count = t.count(i)

print(max, "is repeated",count,"times")
