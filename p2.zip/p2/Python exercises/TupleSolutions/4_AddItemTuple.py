t = (1,2,3)#creating tuple with numbers
print(t)#printing tuple before adding

t = t + (4,) #adding item to tuple
print(type(t))#printing type of t

print(t)#printing tuple after adding
