t = (1,2,3,4)
t2=()
for i in t:
    if(i%2==0):
        t2 = t2 + (i,)
print(t)
print(t2)
