t = (1,2,3,4)
print(t)
item = int(input("Enter an item to find its index: "))

if item in t:
    print("Item index is",t.index(item))
else:
    print("Item not found")
