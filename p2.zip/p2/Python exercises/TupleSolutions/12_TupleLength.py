t = (1,2,3,4)
print(len(t))
c = 0
for i in t:
    c += 1
print("Length of a tuple is",c)
