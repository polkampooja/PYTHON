t = (1,2,3,4,5,6)
print(t)
ind = int(input("Enter an index to remove an item from tuple: "))
l = list(t)
if(ind >= len(l) or ind < 0):
    print("Invalid index we cant remove, index should be in between 0 to",len(l)-1)
else:
    l.pop(ind)
    t = tuple(l)
    print(t)
