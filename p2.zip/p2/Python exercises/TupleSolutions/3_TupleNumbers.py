t = (1,2,3)#creating tuple with numbers
print(t)#printing tuple
print(type(t))#printing type of t
