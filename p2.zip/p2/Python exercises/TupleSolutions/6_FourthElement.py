t = (1,2,3,4,5,6,7,8)
print(t[3])#printing 4th element
print(t[-4])#printing 4th element from last

print(t)#printing tuple
