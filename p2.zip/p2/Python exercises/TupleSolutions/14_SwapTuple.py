t= ("hello", "hai") #creating a tuple
print(t)#printing tuple before swaping
a,b = t #unpacking tuple
print (a,b)#printing a and b before swaping

a,b = b, a #swaping elements
print(a,b)#printing a and b after swaping

t = (a,b) #packing tuple
print(t)#printing tuple after swaping
