t = (1,2)#creating tuple
print(t)#printing tuple
print(type(t))#printing type of t
