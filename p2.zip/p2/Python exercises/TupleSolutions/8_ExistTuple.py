t = (1,2,3,4,5,6,7,8)
ele = int(input("Enter an element to check whether its exist or not: "))
if ele in t:
    print("Exist")
else:
    print("Not exist")
