t = (1,2,"hi",[2,3])#creating tuple with different data types
print(t)#printing tuple
print(type(t))#printing type of t
