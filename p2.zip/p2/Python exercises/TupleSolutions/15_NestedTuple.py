t  = (("Hari", 90), ("Shiva", 95), ("Krishna", 99))#nested tuple
print(t) #tuple before update

#editing marks of each student with user input

hm = int(input("Enter Hari marks: "))
sm = int(input("Enter Shiva marks: "))
km = int(input("Enter Krishna marks: "))

a,b = t[0]
c,d = t[1]
e,f = t[2]
t = ((a,hm),(c,sm),(e,km))#updating marks of all students

print(t)#tuple after update
