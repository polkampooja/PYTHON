t = (1,2,3,4)
print(t)
print(t[::-1])#reverse a tuple
