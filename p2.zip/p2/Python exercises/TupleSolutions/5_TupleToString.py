t = (1,2,3)#creating tuple with numbers
print(t)#printing tuple before adding

a = str(t) #converting tuple to a string
print(a)
print(type(a))
