# Program to multiply two matrices using nested loops
# 3x3 matrix

X = [[12,7,3],
     [4 ,5,6],
    [7 ,8,9]]
# 3x4 matrix
print("Source X matrix is")
for x in X:
    print(x)
Y = [[5,8,1],
    [6,7,3],
    [4,5,9]]
print("Source Y matrix is")
for y in Y:
    print(y)
# result is 3x3
result = [[0,0,0],
        [0,0,0],
        [0,0,0]]
# iterate through rows of X
for i in range(len(X)):
       # iterate through columns of Y
    for j in range(len(Y[0])):
           # iterate through rows of Y
        for k in range(len(Y)):
            result[i][j] += X[i][j] + Y[i][j]

print("Result X+Y matrix is")            
for r in result:
    print(r)
