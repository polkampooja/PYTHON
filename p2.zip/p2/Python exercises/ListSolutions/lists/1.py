"""Write a program to that creates a list of numbers from 1-20 that are either divisible by 2 or 4."""
l=[]
for i in range(1,21):
	if i%2==0 or i%4==0:
		#l.append(i)
		l=l+[i]
print (l)

