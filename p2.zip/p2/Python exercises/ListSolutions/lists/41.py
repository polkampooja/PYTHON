l=[1,2,3,4,5]
for index, i in enumerate(l):
	print (i,"is at index",index)

