l=[2,3,1,4,2,1,5,4,5]
for i in range(len(l)):
	num=l[i]
	for j in range(i+1,len(l)):
		val=l[j]
		if val==num:
			l.remove(j)
print ("after deleting even list is:",l)
		
