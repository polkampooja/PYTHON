"""6. Write a program to print index at which a particular value exists. If the value exists at multiple locations
in the list, then print all the indices. Also, count the number of times that the value is repeated in the list."""
l=[1,2,1,3,5]
num=int(input("enter a number"))
count=0
for i in range(len(l)):
	if num==l[i]:
		print (l[i],"num found at index",i)
		count=count+1
print (num,"count is",count)
