l=[1,2,1,3,4,5,2,5]
print ("original list",l)
m=[]
for i in l:
        if i not in m:
                m = m + [i]
print(m)
