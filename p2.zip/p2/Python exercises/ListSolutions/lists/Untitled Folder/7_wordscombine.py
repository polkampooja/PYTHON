"""7. Write a program that creates a list of words by combining the words in two individual lists."""
L=[]
for x in ["hello","world"]:
	for y in ["python","programming"]:
		word=x+y
		L.append(word)
print ("list combining the words in two individuals list is:",L)
