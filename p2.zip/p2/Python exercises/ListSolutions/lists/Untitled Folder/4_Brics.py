"""4. Write a python program the defines a list of countries that are a member of BRICS. Check whether a
country is a member of BRICS or not."""
BRICS=["Brazil","India","China","Russia","Sri Lanka"]
member=input("enter a country name:")
if member in BRICS:
	print (member,"has member in brics")
else:
	print(member,"has not in list")

