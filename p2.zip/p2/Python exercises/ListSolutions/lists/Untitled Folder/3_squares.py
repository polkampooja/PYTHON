"""3. Write a program to generate a list of squares from 1-10."""
l=[]
for i in range(1,11):
	#l.append(i**2)
	l=l+[i*i]
print l
