"""5. Write a python program to create a list of numbers in the range 1 to 10. Then delete all the even
numbers from the list and print the final list."""
l=[]
for i in range(1,11):
	l.append(i)
print ("original list",l)
for i in l:
	if i%2==0:
		l.remove(i)
print ("after deleting even list is:",l)
		
