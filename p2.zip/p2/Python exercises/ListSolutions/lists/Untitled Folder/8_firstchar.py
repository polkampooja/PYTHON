"""8. Write a program that forms a list of first character of every word in the another list."""
L=["Hai", "Cllo","Namaste","Vanakkam"]
letters=[]
for word in L:
	letters.append(word[0])
print letters
