"""10. Write a program that creates a list of 10 random integers. Then create two lists-odd list even list that
has all odd and even values in the list."""
#import random
numlist=[]
for i in range(10):
	val=int(input("enter a random value"))
	numlist.append(val)
print ("original list",numlist)
oddlist=[]
evenlist=[]
for i in range(len(numlist)):
	if numlist[i]%2==0:
		evenlist.append(numlist[i])
	else:
		oddlist.append(numlist[i])
print ("evenlist:",evenlist)
print ("oddlist:",oddlist)
                                                        

