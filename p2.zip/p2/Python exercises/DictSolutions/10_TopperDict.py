"""
Write a program that has dictionary of names of students and a list of their
marks in 4 subjects. Create another dictionary from this dictionary that has
name of the students and their total marks.
Find out the topper and his/her score.
"""

dict = {'Ramya':[20,30,40,50], 'Shivani':[30,50,43,56], 'pooja':[15,65,46,54]}
dict2={}
for i in dict:
    dict2[i]=sum(dict[i])
topper = max(dict2.values())
for i in dict2:
    if(dict2[i]==topper):
        print("The topper is",i,"with marks",topper)
