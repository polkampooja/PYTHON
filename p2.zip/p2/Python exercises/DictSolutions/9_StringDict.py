"""Write a Python program to create a dictionary from a string.
Note: Track the count of the letters from the string.
Sample string : 'rguktbasar'

Expected output: {'r': 2, 'g': 1, 'u': 1, 'k': 1, 't': 1, 'b': 1, 'a': 2,
                  's': 1}"""
s = 'hello'
dict = {}
for i in s:
    dict[i]=s.count(i)
print(dict)
