#Write a Python program to sort a dictionary by key.
d = {'Red': 1, 'Green': 2, 'Blue': 3}
print(sorted(d.items()))
print(d)



d={1:9,4:5,6:7}
print(d)
print(sorted(d.items()))
s={1:1,5:4,7:6}
print(sorted(s.items()))
