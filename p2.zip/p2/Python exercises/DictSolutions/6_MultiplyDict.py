#Write a Python program to multiply all the items in a dictionary.
my_dict = {'data1':10,'data2':5,'data3':27}
k=1
for i in my_dict:
    k = k * my_dict[i]
print(k)
