#Write a Python program to iterate over dictionaries using for loops.
d = {'Red': 1, 'Green': 2, 'Blue': 3}
for i in d:
    print(i,"Correspondent to",d[i])
