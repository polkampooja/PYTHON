"""Write a program to print the following pattern.
A
AB
ABC
ABCD
ABCDE
ABCDEF
"""
size = int(input("Enter a number: "))
k=65
for i in range(1, size):
    for j in range(1,i+1):
        print(chr(k),end="")
        k=k+1
        if(k>90):
            k=65
    print("")
    k=65
