"""Write a program to reverse of string."""


str = input("enter a string: ")
str2=""
for i in range(len(str)-1,-1,-1):
    str2 = str2 + str[i]
print("Given string is:",str)
str = str2
print("Reverse of the string is:",str)
