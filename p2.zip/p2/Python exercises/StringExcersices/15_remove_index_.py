"""
Write a Python program to remove the characters
which have odd index values of a given string.
"""
s= input ("enter the any string = ")
e=f=""
for i in range(0,len(s)):
    if i%2==0:
        e=e+s[i]
    else:
        f=f+s[i]
    
print("odd remove index " , e)
print("even remove index " , f)
