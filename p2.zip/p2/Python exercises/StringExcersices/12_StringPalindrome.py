"""Write a program to find whether the given string is palindrome string or not."""

str = input("enter a string: ")
str.upper()
str2=""
for i in range(len(str)-1,-1,-1):
    str2 = str2 + str[i]

if(str==str2):
    print("Given string is a palindrome")
else:
    print("Given string is not a palindrome")
