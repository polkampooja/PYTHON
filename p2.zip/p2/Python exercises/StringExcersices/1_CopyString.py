"""

Write a Python program to copy the string using for loop(using range and
without using range function)

"""
str = input("Enter a string: ")
print(str)
str2=""
str3=""
for i in range(0, len(str)):
    str2 = str2+str[i]
print(str2)

for j in str:
    str3 = str3+j
print(str3)

