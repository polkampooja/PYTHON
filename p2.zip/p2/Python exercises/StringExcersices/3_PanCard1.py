"""Write a python that takes user’s name and PAN card number as input.
Validate the information using is X function and print the details."""v
name=input("Enter your name: ")
p=input("Enter pan number:" )
if name.isupper()==True:
	if (p[0:4].isupper() and p[5:8].isdigit() and p[:-1].isupper and len(p)==10)==True:
		print "name and pan is valid"
	else:
		print "name and pan invalid"
 
