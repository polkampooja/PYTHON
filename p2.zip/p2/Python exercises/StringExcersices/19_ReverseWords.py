"""Write a Python program to reverse words in a string."""

str = input("Enter a string: ")
l = str.split()
l = str[::-1]
str = ' '.join(l)
print(str)
