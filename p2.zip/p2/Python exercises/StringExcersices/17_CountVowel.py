"""Write a Python program to count and display the vowels of a given text."""

str = input("Enter a string: ")
str2=""
count=0

for i in str:
    if(i=='a' or i=='A' or i=='e' or i=='E' or i=='i' or i=='I' or i=='o' or i=='O' or i=='u' or i=='U'):
        count=count+1
        print(i,end=" ")
print("\nTotal vowels are:",count)
