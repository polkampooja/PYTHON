"""Write a Python program to count occurrences of a substring in a string"""

str = input("Enter a string: ")
subs = input("Enter a sub string: ")

print(str.count(subs))

