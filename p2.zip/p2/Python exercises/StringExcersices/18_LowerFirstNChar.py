"""Write a Python program to lowercase first n characters in a string."""

str = input("Enter a string: ")
n = int(input("Enter a number to make first n char in lower: "))
str2=""
if(n>len(str)-1):
    print("n value should be less than to string length")
else:
    str2 = str2 + str[:n].lower() + str[n:]
    print(str2)
    str2=""
