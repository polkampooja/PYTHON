"""Write a program that finds a character in a string from ending of string to
beginning that like rfind function."""


str = input("enter a string: ")
char = input("Enter a char: ")
k=-1
for i in range(len(str)-1,-1,-1):
    if(char[0]==str[i]):
        k=i
        break
if(k!=-1):
    print("Search key found at index",k)
else:
    print("Search key is not found")
