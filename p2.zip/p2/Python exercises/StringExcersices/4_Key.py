"""Write a program that encrypts a message by adding a key value to every
character. Hint: say, if key=3, then add 3 to every character"""

str = input("Enter a string: ")
key = int(input("Enter key to encrypt: "))
enc=""
for i in str:
    enc =enc+chr((ord(i))+key)
print(enc)
