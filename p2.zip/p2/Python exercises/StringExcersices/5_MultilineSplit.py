"""Write a program to that uses split() to split multiline string."""

a = """ hello how 
are you I am fine 
what are you doing"""
b = a.split()
print(b)
