"""Write a program that accepts a string from user and redisplays the same
string after removing vowels from it."""

str = input("Enter a string: ")
str2=""
for i in str:
    if(i=='a' or i=='A' or i=='e' or i=='E' or i=='i' or i=='I' or i=='o' or i=='O' or i=='u' or i=='U'):
        str2 = str2
    else:
        str2 = str2+i
#str=str2
print(str2)
