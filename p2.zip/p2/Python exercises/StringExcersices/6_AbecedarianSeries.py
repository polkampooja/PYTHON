"""Write a program to generate Abecedarian series.
Hint: Abecedarian refers to a series or list in which the elements appear in
an alphabetical order."""

size = int(input("Enter list size: "))
l=[]
k=65
for i in range(0,size):
    l = l + [chr(k)]
    k=k+1
    if(k>90):
        k=65
print(l)

m = ["Cat", "Banana","Apple"]
m.sort()
print(m)
