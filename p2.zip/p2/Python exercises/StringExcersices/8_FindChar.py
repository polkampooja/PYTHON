"""Write a program that finds whether a given character is present in a string
or not. In case it is present it prints the index at which it is present. Do not
use built-in find functions to search the character."""

str = input("enter a string: ")
char = input("Enter a char: ")
k=-1
for i in range(0,len(str)):
    if(char[0]==str[i]):
        k=i
        break
if(k!=-1):
    print("Search key found at index",k)
else:
    print("Search key is not found")
