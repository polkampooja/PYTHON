"""Write a Python program to get a string from a given string where all
occurrences of its first char have been changed to '$', except the first char
itself.
Sample String : 'restart' Expected Result : 'resta$t"""

str = input("Enter a string: ")
str2=""+str[0]
for i in range(1,len(str)):
    if(str[i]==str[0]):
        str2=str2+'$'
    else:
        str2=str2+str[i]

print(str2)
