"""Write a python program that count the occurrences of a character in a string
and also counting from the specified location . Do not use string count function"""


str = input("enter a string: ")
char = input("Enter a char: ")
start = int(input("Enter a starting position: "))
end = int(input("Enter an end position: "))
count=0

if (end<=start or start>=len(str)):
    print("Invalid start and end positions")
else:
    for i in range(start, end):
        if(char[0]==str[i]):
            count+=1

    print("Total number of occurences of given char is: ",count)
