s=input("enter the any string :")
print("lower case ",s.lower())
print("upper case ",s.upper())
