"""Write a Python function to reverse a string if it's length is a multiple of 4."""

str = input("enter a string: ")
str2=""
if(len(str)%4==0):
    for i in range(len(str)-1,-1,-1):
        str2 = str2 + str[i]
    print("Given string is:",str)
    str = str2
    print("Reverse of the string is:",str)
else:
    print("Reverse is not posible because string length is not multiple of 4")
